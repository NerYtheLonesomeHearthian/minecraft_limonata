/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package limonata.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import limonata.fluid.LemonadeFluid;

import limonata.LimonataMod;

public class LimonataModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(BuiltInRegistries.FLUID, LimonataMod.MODID);
	public static final DeferredHolder<Fluid, FlowingFluid> LEMONADE = REGISTRY.register("lemonade", () -> new LemonadeFluid.Source());
	public static final DeferredHolder<Fluid, FlowingFluid> FLOWING_LEMONADE = REGISTRY.register("flowing_lemonade", () -> new LemonadeFluid.Flowing());

	@EventBusSubscriber(Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(LEMONADE.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_LEMONADE.get(), RenderType.translucent());
		}
	}
}